Fugue Icons
================================================================================
Copyright (C) 2009 Yusuke Kamiyamane. All rights reserved.
The icons are licensed under a Creative Commons Attribution 3.0 license.
<http://creativecommons.org/licenses/by/3.0/>
--------------------------------------------------------------------------------
If you can't or don't want to place link back, please purchase a royalty-free license.
<http://www.pinvoke.com/>
--------------------------------------------------------------------------------
I'm unavailable for custom icon design work. But your suggestions are always welcome!
<mailto:yusuke.kamiyamane@gmail.com>